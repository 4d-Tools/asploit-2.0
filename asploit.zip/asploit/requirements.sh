####requirements######

apt-get update
apt install -y python python2 ruby fish bash php figlet toilet openssh
#####end########
echo "All Prerequests are installed pls run the phishing websites installer in main"
###############
