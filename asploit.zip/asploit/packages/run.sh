#############################
#SQLMAP STARTER SET LINKED##
############################

clear
cd sqlmap
cowsay "SQL MAP BY ANUBHAB";

echo "Which URL TYPE OR PASTE HERE"
read url 
echo  "starting the dbs attack "

python2 sqlmap.py -u $url --dbs


