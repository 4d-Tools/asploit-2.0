############################
####Shell Link With ASPLOIT#
############################

cd main && chmod +x ngrok && ./ngrok http 4444

#######
######
