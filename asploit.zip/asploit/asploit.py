#python Sploits
####by anubhab####

import os
import subprocess

os.system("clear");
os.system("toilet -f mono12 a-sploit");

print("1.Phishing Attack");
print("2.Spoofing Attack");
print("3.sqlinjection");
print("4.credits");
print("5.Port Forwarding");
print("6.Exit");


choice = int(input("ENTER CHOICE :"));



if choice ==1:
  os.system("cd main && chmod +x phish.py && python2 phish.py");


if choice ==2:
  os.system("cd main")
  os.system("chmod +x spoofer.py")
  os.system("python2 spoofer.py");

if choice ==3:
   os.system("cd main")
   os.system("chmod +x webhacker.py")
   os.system("python webhacker.py");
             
if choice ==4:
 os.system("cd creds && chmod +x creds.sh && bash creds.sh");

if choice ==5:
 os.system("cd portfoward && chmod +x menu.py && python2 menu.py");

if choice ==6:
 exit();
