####requirements######

apt-get update
apt install -y python python2 ruby fish bash php figlet toilet openssh bettercap coway
apt upgrade -y
###############

echo "pls wait UNZIPPING PACAKGES";
cd packages && unzip sqlmap.zip && cd sqlmap && chmod +x *
cd .. && cd ..
echo "UNZIPPING NGROK AND MAKING IT EXECUATABLE";
cd portfoward && unzip ngrok && chmod +x ngrok
echo "All Pacakage Installed successfully";
cd .. && cd packages && rm -rf sqlmap.zip && cd ..
cd portfoward && rm -rf ngrok.zip
echo "Starting cleanup ....done";
echo "All done :)";
################# 
