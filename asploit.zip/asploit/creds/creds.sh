#colors 
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
reset='\033[0m'

echo "maintend by anubhab";
echo "updated by anubhab";
echo "published by anubhab";

###exit

